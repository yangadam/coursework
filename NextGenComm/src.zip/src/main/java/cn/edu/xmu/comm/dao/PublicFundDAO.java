package cn.edu.xmu.comm.dao;

/**
 * description
 *
 * @author Mengmeng Yang
 * @version 1/5/2015 0005
 */
public interface PublicFundDAO {
}
