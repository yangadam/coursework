use comm;
update billitem set isCalculated = 1;